import pandas as pd
import matplotlib.pyplot as plt

plt.rc('font', family='Malgun Gothic')
plt.rcParams['figure.figsize'] = [16, 8]

smoking_area = pd.read_csv('D:\흡연구역.csv')
smoking_crack = pd.read_csv('D:\흡연단속.csv', encoding = 'cp949')
seoul = pd.read_csv('D:\서울.csv', encoding = 'cp949')

smoking_area_count = smoking_area.value_counts('자치구명')

seoul_temp = seoul[seoul.iloc[:,0].isin(smoking_area.iloc[:,0].drop_duplicates())].set_index('자치구명')
density_smoke = (seoul_temp.loc[:,'인구'] / seoul_temp.loc[:,'면적']) / smoking_area_count
density_smoke = density_smoke.sort_values(ascending=False)

rank = pd.DataFrame({'흡연구역 필요성 순위' : density_smoke.index})
rank.index = rank.index+1

print(rank)
